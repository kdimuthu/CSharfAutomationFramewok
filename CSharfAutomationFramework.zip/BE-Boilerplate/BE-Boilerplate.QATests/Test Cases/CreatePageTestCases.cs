﻿using BE_Boilerplate.QATests.Pages;
using BE_Boilerplate.QATests.Utility;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_Boilerplate.QATests.Test_Cases
{
    public class CreatePageTestCases : SeleniumTestBase
    {
        CreateUserPage _CreateUserPage;

        [Test]
        public void TC_001_CreateAUser()
        {
            _CreateUserPage = new CreateUserPage(driver);
            //Open the portal
            _CreateUserPage.Bf_OpenPortal();
            //User Count before creating a new user
            int UserCountBeforeCreateNewUser = _CreateUserPage.Bf_GetUserCount();
            //Enter User Create Details
            _CreateUserPage.Bf_EnterCreateUserDetails("Dimuthu","0713044935","dimuthu@gmail.com");
            //Click Save
            _CreateUserPage.Bf_ClickSave();
            //User Count after creating a new user
            int UserCountAfterCreateNewUser = _CreateUserPage.Bf_GetUserCount();
            //Verify user count before & after creating a new user
            _CreateUserPage.Bf_VerifyCreatedUser(UserCountBeforeCreateNewUser, UserCountAfterCreateNewUser);
        }

        /*[Test]
        public void TC_002_CreateAUser()
        {
            _CreateUserPage = new CreateUserPage(driver);
            //Open the portal
            _CreateUserPage.Bf_OpenPortal();
            //User Count before creating a new user
            int UserCountBeforeCreateNewUser = _CreateUserPage.Bf_GetUserCount();
            //Enter User Create Details
            _CreateUserPage.Bf_EnterCreateUserDetails("Dimuthu", "0713044935", "dimuthu@gmail.com");
            //Click Save
            _CreateUserPage.Bf_ClickSave();
            //User Count after creating a new user
            int UserCountAfterCreateNewUser = _CreateUserPage.Bf_GetUserCount();
            //Verify user count before & after creating a new user
            _CreateUserPage.Bf_VerifyCreatedUser(UserCountBeforeCreateNewUser, 0);
        }*/
    }
}
