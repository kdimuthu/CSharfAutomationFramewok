﻿using BE_Boilerplate.QATests.Pages;
using BE_Boilerplate.QATests.Utility;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_Boilerplate.QATests.Test_Cases
{
    public class ExpTest : SeleniumTestBase
    {
        CreateUserPage _CreateUserPage;

        [Test]
        public void TC_CreateAUser()
        {
            _CreateUserPage = new CreateUserPage(driver);
            //Open the portal
            _CreateUserPage.Bf_OpenPortal();
            //User Count before creating a new user
            _CreateUserPage.Bf_DoExp();
        }
    }
}
