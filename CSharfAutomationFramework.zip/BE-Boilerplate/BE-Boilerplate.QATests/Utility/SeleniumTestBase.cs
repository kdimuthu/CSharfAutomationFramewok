﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.MarkupUtils;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System;
using System.IO;
using NUnit.Framework.Interfaces;

namespace BE_Boilerplate.QATests.Utility
{
    public class SeleniumTestBase
    {
        //Webdriver        
        public IWebDriver driver;
        //Broser name to be executed
        public string BrowserType = "chrome";        
       // ExtentHtmlReporter extenReports;
        public  ExtentReports _extent;
        //Write logs to Report
#pragma warning disable CA2211 // Non-constant fields should not be visible
        protected static ExtentTest logs;
#pragma warning restore CA2211 // Non-constant fields should not be visible
                              //Test case name
        public string TestCase_Name = null;

        //Initiate the execution report
        [OneTimeSetUp]
        public void StartReport()
        {
            var path = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            var actualPath = path.Substring(0, path.LastIndexOf("bin"));
            var projectPath = new Uri(actualPath).LocalPath;
            Directory.CreateDirectory("Outputs");
            string TimesStamp = DateTime.Now.ToString("_yyyy-MM-dd_hh-mm-ss");
            var reportPath = projectPath + "Outputs\\ExecutionReport" + TimesStamp + "\\Index.html";
            var htmlReporter = new ExtentHtmlReporter(reportPath);
            _extent = new ExtentReports();
            _extent.AttachReporter(htmlReporter);
            htmlReporter.LoadConfig(projectPath + "report-config.xml");
        }

        //Open the Browser
        [SetUp]
        public void OpenBrowser()
        {
            //Get the test case name
            TestCase_Name = TestContext.CurrentContext.Test.Name;
            //Create a entry for each test case in execution report
            logs = _extent.CreateTest(TestCase_Name);           
            switch (BrowserType)
            {
                case "chrome":
                    // Create a driver instance for chromedriver
                    driver = new ChromeDriver();                  
                    logs.Log(Status.Info, "Executing in Chrome Browser");
                    break;

                case "firefox":
                    // Create a driver instance for firefoxdriver
                    driver = new FirefoxDriver();
                        logs.Log(Status.Info, "Executing in Firefox browser");
                    break;

                case "InternetExplorer":
                    // Create a driver instance for firefoxdriver
                    /*TBD*/
                    logs.Log(Status.Info, "Executing in IE browser");
                    break;

                case "HeadlessChrome":
                    //Execute in headless mode for chrome
                    ChromeOptions Option = new ();
                    Option.AddArguments("headless");
                    driver = new ChromeDriver(Option);
                    logs.Log(Status.Info, "Executing in chrome browser headless mode");
                    break;

                default:                   
                    logs.Log(Status.Error,"BROWSER_TYPE not identified. Starting default type");
                    throw new Exception("BROWSER_TYPE not identified.Starting default type");
            }
            //Implicit wait
            driver.Manage().Timeouts().ImplicitWait= TimeSpan.FromSeconds(10);
            //Maximize the browser
            driver.Manage().Window.Maximize();
            logs.Log(Status.Info, "Starting the execution of tests case " + TestCase_Name);
        }

        //Close Brower
        [TearDown]
        public void CloseBrowser()
        {
            var exec_status = TestContext.CurrentContext.Result.Outcome.Status;
            TestCase_Name = TestContext.CurrentContext.Test.Name;
            var ErrorMessage = TestContext.CurrentContext.Result.Message;

            switch (exec_status)
            {
                case TestStatus.Passed:                    
                    logs.Log(Status.Pass, MarkupHelper.CreateLabel(TestCase_Name, ExtentColor.Green));
                    logs.Log(Status.Info, "Ending the Executino of test case " + TestCase_Name);
                    break;

                case TestStatus.Failed:
                    logs.Log(Status.Fail, MarkupHelper.CreateLabel(TestCase_Name+" is fail due to following reason", ExtentColor.Red));
                    logs.Log(Status.Fail, MarkupHelper.CreateLabel(ErrorMessage, ExtentColor.Red));
                    //   _test.Log(Status.Fail, "Fail");
                    //   _test.Log(Status.Fail, "Traditional Snapshot below: " + _test.AddScreenCaptureFromPath("Screenshots\\" + fileName));
                    break;

                case TestStatus.Inconclusive:
                    logs.Log(Status.Warning, MarkupHelper.CreateLabel(TestCase_Name+ " is in Inconclusive status", ExtentColor.Amber));
                    break;
                case TestStatus.Skipped:
                    logs.Log(Status.Skip, MarkupHelper.CreateLabel(TestCase_Name+" Skipped & Not Executed", ExtentColor.Orange));
                    break;
                default:
                    break;
            }            
            //Closing the browwer
            // driver.Close();
            // driver.Quit();
        }


        /*    
         *    Start the test execution report using Extent Reports.
         */


        //Closing the executino report at the end of test cycle

        [OneTimeTearDown]
        public void CloseReport()
        {
            _extent.Flush();
        }
    }
}
