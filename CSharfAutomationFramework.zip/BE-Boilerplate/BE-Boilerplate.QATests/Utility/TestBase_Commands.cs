﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.MarkupUtils;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;



namespace BE_Boilerplate.QATests.Utility
{
    public class TestBase_Commands : SeleniumTestBase
    {
		/*wait for the explicit wait*/
		private static WebDriverWait wait;

		/* Timeout for explicit wait */
		private static int timeOut = 10;

		/*
			Sets the driver. 
			<param name="driver">the new web driver</param>
		*/

		public void SetDriver(IWebDriver driver)
		{
			this.driver = driver;
		}

		/*
				Get the driver. 
				retun the driver
		*/
		public IWebDriver GetDriver()
		{
			return driver;
		}

		/*
			Launch the application.
			<param name="URL">URL of the applicationr</param>
		*/

		public void Open(String URL)
		{
            try
            {
                GetDriver().Navigate().GoToUrl(URL);
				logs.Log(Status.Info, "Opened the system [" + URL + "] successfully");
			}
            catch (Exception e)
            {
				logs.Log(Status.Error, MarkupHelper.CreateLabel("Fail to open the browser due to " + e.Message, ExtentColor.Red));					
            }
		}


		/*
			Click on a element
			<param name="byLocator">object locator</param>
		*/

		public void Click(By byLocator)
        {
			try
			{
				try
				{
					wait = new WebDriverWait(GetDriver(), TimeSpan.FromSeconds(timeOut));
					wait.Until(e => e.FindElement(byLocator));			
				}
				catch (WebDriverTimeoutException)
				{
					logs.Log(Status.Info, byLocator + " element is not visible");
				}
				IWebElement Element = GetDriver().FindElement(byLocator);
				Element.Click();
				logs.Log(Status.Info, "Clicked on the element '" + byLocator + "'");
			}

			catch (Exception e)
            {				
                logs.Log(Status.Error, MarkupHelper.CreateLabel(e.Message, ExtentColor.Red));
				throw;
            }
		}

		/*
			Type on a element
			<param name="byLocator">object locator</param>
			<param name="text">text to be typed</param>
		*/

		public void Type(By byLocator, string text)
		{
			try
			{
				try
				{
					wait = new WebDriverWait(GetDriver(), TimeSpan.FromSeconds(timeOut));
					//wait.Until(ExpectedConditions.ElementExists(byLocator));
					wait.Until(e => e.FindElement(byLocator));
				}
				catch (TimeoutException)
				{
				}
				IWebElement Element = GetDriver().FindElement(byLocator);
				Element.SendKeys(text);
			}
			catch (Exception)
			{
				throw;
			}
		}

		/*
			Store a text on element
			<param name="byLocator">object locator</param>
		*/

		public string StoreText(By byLocator)
		{
			try
			{
				try
				{
					wait = new WebDriverWait(GetDriver(), TimeSpan.FromSeconds(timeOut));
					wait.Until(e => e.FindElement(byLocator));
				}
				catch (TimeoutException)
				{
					
				}
				string ElementText = GetDriver().FindElement(byLocator).Text;
				
				return ElementText;
			}
			catch (Exception)
			{
				throw;
			}		
		}


		/*
			Get the element count for element with set of matching
			<param name="byLocator">object locator</param>
		*/

		public int GetCount(By byLocator)
		{
            try
            {
                try
                {
                    wait = new WebDriverWait(GetDriver(), TimeSpan.FromSeconds(timeOut));
                    wait.Until(ExpectedConditions.ElementExists(byLocator));

                }
                catch (TimeoutException)
                {
                    
                }
                int ItemCount = GetDriver().FindElements(byLocator).Count;
                return ItemCount;
            }
            catch (Exception)
            {

                throw;
            }
		}


		/*
			Verify a text or message
			<param name="byLocator">object locator</param>
			<param name="text">text to be verified</param>
		*/

		public void VerifyText(By byLocator, string text)
		{
            try
            {
                try
                {
                    wait = new WebDriverWait(GetDriver(), TimeSpan.FromSeconds(timeOut));
					wait.Until(e => e.FindElement(byLocator));

				}
                catch (TimeoutException)
                {

                }
                string actualtMessage = driver.FindElement(byLocator).Text;
                string expectedMessage = text;
                Assert.AreEqual(actualtMessage, expectedMessage);
            }
            catch (Exception)
            {

                throw;
            }
		}

		/*
			Clear on input field
			<param name="byLocator">object locator</param>			
		*/

		public void Clear(By byLocator)
		{
			try
			{
				try
				{
					wait = new WebDriverWait(GetDriver(), TimeSpan.FromSeconds(timeOut));
					wait.Until(e => e.FindElement(byLocator));
				}
				catch (TimeoutException)
				{
				}
				IWebElement Element = GetDriver().FindElement(byLocator);				
				Element.Clear();
			}
			catch (Exception)
			{
				throw;
			}
		}

		/*
			Clear on input field(Will Click before clearing)
			<param name="byLocator">object locator</param>			
		*/

		public void ClickAndClear(By byLocator)
		{
			try
			{
				try
				{
					wait = new WebDriverWait(GetDriver(), TimeSpan.FromSeconds(timeOut));
					wait.Until(e => e.FindElement(byLocator));
				}
				catch (TimeoutException)
				{
				}
				IWebElement Element = GetDriver().FindElement(byLocator);
				Element.Click();
				Element.Clear();
			}
			catch (Exception)
			{
				throw;
			}
		}


		/*
			Clear on input field
			<param name="byLocator">object locator</param>	
			<param name="byLocator">object locator</param>
		
		*/

		public void ClearAndType(By byLocator, string text)
		{
			try
			{
				try
				{
					wait = new WebDriverWait(GetDriver(), TimeSpan.FromSeconds(timeOut));
					wait.Until(e => e.FindElement(byLocator));
				}
				catch (TimeoutException)
				{
				}
				IWebElement Element = GetDriver().FindElement(byLocator);
				Element.Clear();
				Element.SendKeys(text);
			}
			catch (Exception)
			{
				throw;
			}
		}
		/*
			Verify a text or message
			<param name="byLocator">object locator</param>
			<param name="text">text to be verified</param>
		*/

		
	}
}
