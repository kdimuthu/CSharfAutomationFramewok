﻿using BE_Boilerplate.QATests.Utility;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;


namespace BE_Boilerplate.QATests.Pages
{
    public class CreateUserPage : TestBase_Commands
    {
        private readonly By tf_Name = By.XPath("//input[@name='name']");
        private readonly By tf_PhoneNumber = By.XPath("//input[@name='phoneNumber']");
        private readonly By tf_EmailAddress = By.XPath("//input[@name='email']");
        private readonly By btn_Save = By.XPath("//button[text()='Save']");
        private readonly By Itm_NumberOfUsersInList = By.XPath("//tbody/tr");

        public CreateUserPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        //Create User
        public void Bf_OpenPortal()
        {
            //Open the browser
            Open("https://qa-fe-boilerplate.azurewebsites.net/");

        }

        //Create User
        public void Bf_EnterCreateUserDetails(string prm_Name, string prm_PhoneNumber, string prm_Email)
        {
            //Enter Name
            Type(tf_Name, prm_Name);
            //Enter PhoneNumber
            Type(tf_PhoneNumber, prm_PhoneNumber);
            //Enter Email Address 
            Type(tf_EmailAddress, prm_Email);

        }

        public void Bf_ClickSave()
        {
            //Click Save Button
            Click(btn_Save);
        }

        //Store User Creation Details

        public string[] Bf_StoreDetails()
        {
            string[] UserInformation = new string[3];
            string Name = StoreText(tf_Name);
            UserInformation[0] = Name;
            string PhoneNumber = StoreText(tf_PhoneNumber);
            UserInformation[1] = PhoneNumber;
            string EmailAddress = StoreText(tf_EmailAddress);
            UserInformation[2] = EmailAddress;
            return UserInformation;
        }

        //Get the user count in list

        public int Bf_GetUserCount()
        {
            Thread.Sleep(2000);
            int UserCount = GetCount(Itm_NumberOfUsersInList);
            return UserCount;
        }

        //Verify added user

        public void Bf_VerifyCreatedUser(int prm_UserCountBeforeCreanteNew, int prm_UserCountAfterCreateNew)
        {
            //get the user count before creating a user
            int NumberOfUserBeforeCreateNewUser = prm_UserCountBeforeCreanteNew;
            //get the user count before creating a user
            int NumberOfUserAfterCreateNewUser = prm_UserCountAfterCreateNew;
            //Compare the user count before & after creating a new user
            if (NumberOfUserAfterCreateNewUser == (NumberOfUserBeforeCreateNewUser + 1))
            {
                Assert.Pass("New User Created & Added user are visibled in user list");
            }

            else
            {
                Assert.Fail("Added user are not visibled in user list");
            }
        }

        //Do Exp
        public void Bf_DoExp()
        {
            //Enter Name
            Type(tf_Name, "Dimuthu");
            //Enter PhoneNumber
            Type(tf_PhoneNumber, "0713044944");
            //Enter Email Address 
            Type(tf_EmailAddress, "dfdfd@gmaiil.com");
            //Clear
            Clear(tf_Name);
            ClearAndType(tf_EmailAddress,"clearAndType");

        }
    }
}
