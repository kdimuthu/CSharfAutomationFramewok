using BE_Boilerplate.Controllers;
using BE_Boilerplate.Models;
using BE_Boilerplate.Services;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace BE_Boilerplate.Test
{
    public class UserControllerTest
    {
        [Fact]
        public async Task Get_Users()
        {
            var mockService = new Mock<IUserService>();
            mockService.Setup(s => s.GetAll())
                .ReturnsAsync(GetTestData());

            var controller = new UserController(mockService.Object);
            var result = await controller.Get();
            var items = Assert.IsType<List<User>>(result);
            Assert.Equal(2,items.Count);

        }

        [Fact]
        public async Task Add_User()
        {
            var mockService = new Mock<IUserService>();
            var testUser = new User
            {
                Email = "",
                Id = 3,
                IsActive = false,
                Name = "",
                PhoneNumber = ""
            };

            mockService.Setup(s => s.AddUser(testUser))
                .ReturnsAsync(GetTestUser);

            var controller = new UserController(mockService.Object);

            var result = await controller.Post(testUser);
            var okResult= Assert.IsType<OkObjectResult>(result);
            var returnUser = Assert.IsType<User>(okResult.Value);

            Assert.Equal(testUser.Id, returnUser.Id);

        }

        private List<User> GetTestData()
        {
            var users = new List<User>();
            users.Add(
                new User
                {
                    Id=1,
                    Email="",
                    IsActive=false,
                    Name="",
                    PhoneNumber=""
                });

            users.Add(
               new User
               {
                   Id = 2,
                   Email = "",
                   IsActive = false,
                   Name = "",
                   PhoneNumber = ""
               });

            return users;
        }

        private User GetTestUser()
        {
            var user = new User()
            {
                Id = 3,
                Email = "",
                IsActive = false,
                Name = "",
                PhoneNumber = ""
            };

            return user;
        }
    }
}
