﻿using BE_Boilerplate.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BE_Boilerplate.Repositories
{
    public interface IUserRepository
    {
        Task<IList<User>> GetAll();
        Task<User> GetUser(int id);
        Task<User> AddUser(User user);
        User UpdateUser(int id, User user);
        void DeleteUser(int id);

    }
}
