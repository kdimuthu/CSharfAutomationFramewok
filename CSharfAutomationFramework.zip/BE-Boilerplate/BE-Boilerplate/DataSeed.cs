﻿using BE_Boilerplate.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BE_Boilerplate
{
    public class DataSeed
    {
        public static void Initialize(AppDbContext appDbContext)
        {
            if (appDbContext.Users.Any()) 
            {
                return;
            }

            appDbContext.AddRange(
                new User
                {
                    Id=1,
                    Email="john@mail.com",
                    Name="John Doe",
                    PhoneNumber = "0777777777",
                    IsActive =true
                },
                new User
                {
                    Id = 2,
                    Email = "jaccob@mail.com",
                    Name = "Jaccob Mill",
                    PhoneNumber = "0773456777",
                    IsActive = true
                },
                new User
                {
                    Id = 3,
                    Email = "peterson@mail.com",
                    Name = "Peterson Drill",
                    PhoneNumber = "0777734534",
                    IsActive = true
                }
            );

            appDbContext.SaveChanges();
        }
    }
}
